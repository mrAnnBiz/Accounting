// Paper Code Parser
function parsePaperCode(code) {
  // Example: "9706/32/INSERT/M/J/25" or "0452/12/QP/F/M/25"
  const parts = code.trim().toUpperCase().split('/');
  
  if (parts.length < 5) {
    return null;
  }

  const syllabus = parts[0];
  const component = parts[1];
  const typeText = parts[2];
  const session1 = parts[3];
  const session2 = parts[4];
  const year = parts[5] || '25';

  // Map type text to abbreviation
  const typeMap = {
    'QP': 'qp',
    'MS': 'ms',
    'INSERT': 'in',
    'IN': 'in',
    'GT': 'gt'
  };

  // Map session to abbreviation
  const sessionMap = {
    'F/M': 'f',
    'M/J': 's',
    'O/N': 'w'
  };

  const sessionKey = `${session1}/${session2}`;
  const session = sessionMap[sessionKey] || 's';
  const type = typeMap[typeText] || 'qp';

  const filename = `${syllabus}-${session}${year}-${type}-${component}.pdf`;

  return {
    syllabus,
    component,
    type,
    session,
    year,
    filename,
    displayName: `${syllabus} ${getSessionName(session)} ${year} ${getTypeName(type)} Paper ${component}`
  };
}

function getSessionName(session) {
  const map = {
    'f': 'Feb/Mar',
    's': 'May/Jun',
    'w': 'Oct/Nov'
  };
  return map[session] || session;
}

function getTypeName(type) {
  const map = {
    'qp': 'Question Paper',
    'ms': 'Marking Scheme',
    'in': 'Insert',
    'gt': 'Grade Threshold'
  };
  return map[type] || type;
}

// Sample past papers data
const pastPapersData = [
  // IGCSE 0452
  { syllabus: '0452', year: '25', session: 's', component: '12', type: 'qp' },
  { syllabus: '0452', year: '25', session: 's', component: '12', type: 'ms' },
  { syllabus: '0452', year: '25', session: 's', component: '22', type: 'qp' },
  { syllabus: '0452', year: '25', session: 's', component: '22', type: 'ms' },
  { syllabus: '0452', year: '24', session: 'w', component: '12', type: 'qp' },
  { syllabus: '0452', year: '24', session: 'w', component: '12', type: 'ms' },
  { syllabus: '0452', year: '24', session: 'w', component: '22', type: 'qp' },
  { syllabus: '0452', year: '24', session: 'w', component: '22', type: 'ms' },
  { syllabus: '0452', year: '24', session: 's', component: '12', type: 'qp' },
  { syllabus: '0452', year: '24', session: 's', component: '12', type: 'ms' },
  
  // A-Level 9706
  { syllabus: '9706', year: '25', session: 's', component: '12', type: 'qp' },
  { syllabus: '9706', year: '25', session: 's', component: '12', type: 'ms' },
  { syllabus: '9706', year: '25', session: 's', component: '22', type: 'qp' },
  { syllabus: '9706', year: '25', session: 's', component: '22', type: 'ms' },
  { syllabus: '9706', year: '25', session: 's', component: '32', type: 'qp' },
  { syllabus: '9706', year: '25', session: 's', component: '32', type: 'ms' },
  { syllabus: '9706', year: '25', session: 's', component: '32', type: 'in' },
  { syllabus: '9706', year: '25', session: 's', component: '42', type: 'qp' },
  { syllabus: '9706', year: '25', session: 's', component: '42', type: 'ms' },
  { syllabus: '9706', year: '24', session: 'w', component: '32', type: 'qp' },
  { syllabus: '9706', year: '24', session: 'w', component: '32', type: 'ms' },
  { syllabus: '9706', year: '24', session: 'w', component: '42', type: 'qp' },
  { syllabus: '9706', year: '24', session: 'w', component: '42', type: 'ms' },
];

function generateFilename(paper) {
  return `${paper.syllabus}-${paper.session}${paper.year}-${paper.type}-${paper.component}.pdf`;
}

function getPaperDisplayName(paper) {
  const syllabusName = paper.syllabus === '0452' ? 'IGCSE' : 'A-Level';
  return `${syllabusName} Accounting ${getSessionName(paper.session)} 20${paper.year}`;
}

function getPaperComponent(paper) {
  return `Paper ${paper.component}`;
}

// State management
let currentPage = 'home';
let filteredPapers = [...pastPapersData];
let currentFilters = {
  syllabus: 'all',
  year: 'all',
  session: 'all',
  component: 'all',
  type: 'all'
};

// PDF Viewer State
let currentPaper = null;
let pdfScale = 1.0;
let currentPdfPage = 1;
let totalPdfPages = 0;
let isDrawing = false;
let drawingColor = '#7c3aed';
let drawingSize = 3;
let annotations = [];
let lastX = 0;
let lastY = 0;

// Navigation
function navigateTo(page, data = null) {
  currentPage = page;
  
  if (page === 'home') {
    renderHomePage();
  } else if (page === 'past-papers') {
    renderPastPapersPage();
  } else if (page === 'viewer') {
    currentPaper = data;
    renderViewerPage();
  }
}

// Render functions
function renderHomePage() {
  // Already rendered in HTML
  document.body.innerHTML = `
    <nav class="navbar">
      <div class="container">
        <div class="navbar-content">
          <a href="#" class="logo" id="logoLink">Anneruth</a>
          <div class="nav-links">
            <a href="#" class="nav-link active" id="homeLink">Home</a>
            <a href="#" class="nav-link" id="pastPapersNavLink">Past Papers</a>
          </div>
        </div>
      </div>
    </nav>

    <section class="hero">
      <div class="container">
        <div class="hero-content">
          <h1 class="hero-title">Cambridge Accounting Past Papers</h1>
          <p class="hero-description">Access comprehensive past papers for IGCSE (0452) and A-Level (9706) Accounting. Search, annotate, and study with ease.</p>
          <button class="btn btn--primary btn--lg" id="explorePapersBtn">
            <svg class="icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
              <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
            </svg>
            Explore Past Papers
          </button>
        </div>
      </div>
    </section>

    <section class="features">
      <div class="container">
        <div class="features-grid">
          <div class="feature-card">
            <div class="feature-icon" style="background: var(--color-bg-1);">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.35-4.35"></path>
              </svg>
            </div>
            <h3 class="feature-title">Smart Search</h3>
            <p class="feature-description">Search by paper code (e.g., 9706/32/QP/M/J/25) or use filters to find exactly what you need.</p>
          </div>

          <div class="feature-card">
            <div class="feature-icon" style="background: var(--color-bg-2);">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 20h9"></path>
                <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
              </svg>
            </div>
            <h3 class="feature-title">Annotate Papers</h3>
            <p class="feature-description">Draw and annotate directly on PDFs with full iPad pencil support for effective studying.</p>
          </div>

          <div class="feature-card">
            <div class="feature-icon" style="background: var(--color-bg-3);">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
                <polyline points="10 9 9 9 8 9"></polyline>
              </svg>
            </div>
            <h3 class="feature-title">Linked Resources</h3>
            <p class="feature-description">Access marking schemes, inserts, and grade thresholds linked to each question paper.</p>
          </div>

          <div class="feature-card">
            <div class="feature-icon" style="background: var(--color-bg-4);">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
            </div>
            <h3 class="feature-title">Download Anytime</h3>
            <p class="feature-description">Download original or annotated papers for offline study and reference.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="subjects">
      <div class="container">
        <h2 class="section-title">Available Syllabuses</h2>
        <div class="subjects-grid">
          <div class="subject-card">
            <div class="subject-header">
              <h3 class="subject-title">IGCSE Accounting</h3>
              <span class="subject-code">0452</span>
            </div>
            <div class="subject-info">
              <div class="info-item">
                <span class="info-label">Years:</span>
                <span class="info-value">2016 - 2025</span>
              </div>
              <div class="info-item">
                <span class="info-label">Components:</span>
                <span class="info-value">Paper 1, Paper 2</span>
              </div>
              <div class="info-item">
                <span class="info-label">Sessions:</span>
                <span class="info-value">Feb/Mar, May/Jun, Oct/Nov</span>
              </div>
            </div>
          </div>

          <div class="subject-card">
            <div class="subject-header">
              <h3 class="subject-title">A-Level Accounting</h3>
              <span class="subject-code">9706</span>
            </div>
            <div class="subject-info">
              <div class="info-item">
                <span class="info-label">Years:</span>
                <span class="info-value">2016 - 2025</span>
              </div>
              <div class="info-item">
                <span class="info-label">Components:</span>
                <span class="info-value">AS (P1, P2), A2 (P3, P4)</span>
              </div>
              <div class="info-item">
                <span class="info-label">Sessions:</span>
                <span class="info-value">Feb/Mar, May/Jun, Oct/Nov</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer class="footer">
      <div class="container">
        <p class="footer-text">&copy; 2025 Anneruth. All rights reserved.</p>
      </div>
    </footer>
  `;

  attachHomeListeners();
}

function attachHomeListeners() {
  const explorePapersBtn = document.getElementById('explorePapersBtn');
  const pastPapersNavLink = document.getElementById('pastPapersNavLink');
  const homeLink = document.getElementById('homeLink');
  const logoLink = document.getElementById('logoLink');

  if (explorePapersBtn) {
    explorePapersBtn.addEventListener('click', () => navigateTo('past-papers'));
  }
  if (pastPapersNavLink) {
    pastPapersNavLink.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo('past-papers');
    });
  }
  if (homeLink) {
    homeLink.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo('home');
    });
  }
  if (logoLink) {
    logoLink.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo('home');
    });
  }
}

function renderPastPapersPage() {
  document.body.innerHTML = `
    <nav class="navbar">
      <div class="container">
        <div class="navbar-content">
          <a href="#" class="logo" id="logoLink">Anneruth</a>
          <div class="nav-links">
            <a href="#" class="nav-link" id="homeLink">Home</a>
            <a href="#" class="nav-link active" id="pastPapersNavLink">Past Papers</a>
          </div>
        </div>
      </div>
    </nav>

    <div class="page-header">
      <div class="container">
        <h1 class="page-title">Past Papers</h1>
        <p class="page-description">Search by paper code or use filters to find past papers</p>
      </div>
    </div>

    <section class="search-section">
      <div class="container">
        <div class="search-box">
          <label class="search-label">Search by Paper Code</label>
          <input 
            type="text" 
            class="search-input" 
            id="paperCodeInput"
            placeholder="e.g., 9706/32/QP/M/J/25 or 0452/12/MS/F/M/25"
          />
          <p class="search-help">Enter the full paper code from your question paper or marking scheme</p>
        </div>

        <div class="filters-container">
          <h3 class="filters-title">Filter Papers</h3>
          <div class="filters-grid">
            <div class="filter-group">
              <label>Syllabus</label>
              <select id="filterSyllabus">
                <option value="all">All Syllabuses</option>
                <option value="0452">IGCSE (0452)</option>
                <option value="9706">A-Level (9706)</option>
              </select>
            </div>
            <div class="filter-group">
              <label>Year</label>
              <select id="filterYear">
                <option value="all">All Years</option>
                <option value="25">2025</option>
                <option value="24">2024</option>
                <option value="23">2023</option>
                <option value="22">2022</option>
              </select>
            </div>
            <div class="filter-group">
              <label>Session</label>
              <select id="filterSession">
                <option value="all">All Sessions</option>
                <option value="f">Feb/Mar</option>
                <option value="s">May/Jun</option>
                <option value="w">Oct/Nov</option>
              </select>
            </div>
            <div class="filter-group">
              <label>Component</label>
              <select id="filterComponent">
                <option value="all">All Components</option>
                <option value="12">Paper 12</option>
                <option value="22">Paper 22</option>
                <option value="32">Paper 32</option>
                <option value="42">Paper 42</option>
              </select>
            </div>
            <div class="filter-group">
              <label>Type</label>
              <select id="filterType">
                <option value="all">All Types</option>
                <option value="qp">Question Paper</option>
                <option value="ms">Marking Scheme</option>
                <option value="in">Insert</option>
                <option value="gt">Grade Threshold</option>
              </select>
            </div>
          </div>
          <div style="display: flex; gap: 8px; margin-top: 16px;">
            <button class="btn btn--secondary" id="clearFiltersBtn">Clear Filters</button>
          </div>
        </div>
      </div>
    </section>

    <section class="results-section">
      <div class="container">
        <div class="results-header">
          <span class="results-count" id="resultsCount">0 papers found</span>
        </div>
        <div class="papers-grid" id="papersGrid"></div>
      </div>
    </section>
  `;

  attachPastPapersListeners();
  applyFilters();
}

function attachPastPapersListeners() {
  const logoLink = document.getElementById('logoLink');
  const homeLink = document.getElementById('homeLink');
  const paperCodeInput = document.getElementById('paperCodeInput');
  const clearFiltersBtn = document.getElementById('clearFiltersBtn');

  if (logoLink) {
    logoLink.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo('home');
    });
  }

  if (homeLink) {
    homeLink.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo('home');
    });
  }

  if (paperCodeInput) {
    paperCodeInput.addEventListener('input', handlePaperCodeSearch);
  }

  if (clearFiltersBtn) {
    clearFiltersBtn.addEventListener('click', clearFilters);
  }

  // Filter listeners
  ['filterSyllabus', 'filterYear', 'filterSession', 'filterComponent', 'filterType'].forEach(id => {
    const element = document.getElementById(id);
    if (element) {
      element.addEventListener('change', handleFilterChange);
    }
  });
}

function handlePaperCodeSearch(e) {
  const code = e.target.value.trim();
  
  if (!code) {
    applyFilters();
    return;
  }

  const parsed = parsePaperCode(code);
  
  if (parsed) {
    // Find matching paper
    filteredPapers = pastPapersData.filter(paper => {
      const filename = generateFilename(paper);
      return filename === parsed.filename;
    });
  } else {
    filteredPapers = [];
  }

  renderPaperResults();
}

function handleFilterChange(e) {
  const filterId = e.target.id.replace('filter', '').toLowerCase();
  currentFilters[filterId] = e.target.value;
  applyFilters();
}

function applyFilters() {
  filteredPapers = pastPapersData.filter(paper => {
    if (currentFilters.syllabus !== 'all' && paper.syllabus !== currentFilters.syllabus) return false;
    if (currentFilters.year !== 'all' && paper.year !== currentFilters.year) return false;
    if (currentFilters.session !== 'all' && paper.session !== currentFilters.session) return false;
    if (currentFilters.component !== 'all' && paper.component !== currentFilters.component) return false;
    if (currentFilters.type !== 'all' && paper.type !== currentFilters.type) return false;
    return true;
  });

  renderPaperResults();
}

function clearFilters() {
  currentFilters = {
    syllabus: 'all',
    year: 'all',
    session: 'all',
    component: 'all',
    type: 'all'
  };

  document.getElementById('filterSyllabus').value = 'all';
  document.getElementById('filterYear').value = 'all';
  document.getElementById('filterSession').value = 'all';
  document.getElementById('filterComponent').value = 'all';
  document.getElementById('filterType').value = 'all';
  document.getElementById('paperCodeInput').value = '';

  applyFilters();
}

function renderPaperResults() {
  const resultsCount = document.getElementById('resultsCount');
  const papersGrid = document.getElementById('papersGrid');

  if (!resultsCount || !papersGrid) return;

  resultsCount.textContent = `${filteredPapers.length} paper${filteredPapers.length !== 1 ? 's' : ''} found`;

  if (filteredPapers.length === 0) {
    papersGrid.innerHTML = `
      <div class="empty-state">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"></circle>
          <path d="m21 21-4.35-4.35"></path>
        </svg>
        <h3>No papers found</h3>
        <p>Try adjusting your filters or search criteria</p>
      </div>
    `;
    return;
  }

  papersGrid.innerHTML = filteredPapers.map(paper => {
    const filename = generateFilename(paper);
    const displayName = getPaperDisplayName(paper);
    const component = getPaperComponent(paper);
    const typeDisplay = getTypeName(paper.type);
    
    return `
      <div class="paper-card" data-filename="${filename}">
        <div class="paper-header">
          <span class="paper-type">${typeDisplay}</span>
        </div>
        <h3 class="paper-title">${displayName}</h3>
        <div class="paper-meta">
          <div class="meta-item">${component}</div>
          <div class="meta-item">Syllabus: ${paper.syllabus}</div>
          <div class="meta-item">File: ${filename}</div>
        </div>
        <div class="paper-actions">
          <button class="btn btn--primary btn-icon view-paper" data-paper='${JSON.stringify(paper)}'>
            <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
              <circle cx="12" cy="12" r="3"></circle>
            </svg>
            View
          </button>
          <button class="btn btn--secondary btn-icon download-paper" data-filename="${filename}">
            <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="7 10 12 15 17 10"></polyline>
              <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
            Download
          </button>
        </div>
      </div>
    `;
  }).join('');

  // Attach click listeners to paper cards
  document.querySelectorAll('.view-paper').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const paper = JSON.parse(e.currentTarget.getAttribute('data-paper'));
      navigateTo('viewer', paper);
    });
  });

  document.querySelectorAll('.download-paper').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const filename = e.currentTarget.getAttribute('data-filename');
      downloadPaper(filename);
    });
  });
}

function downloadPaper(filename) {
  const url = `/past-papers/${filename}`;
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
}

function renderViewerPage() {
  if (!currentPaper) {
    navigateTo('past-papers');
    return;
  }

  const displayName = getPaperDisplayName(currentPaper);
  const component = getPaperComponent(currentPaper);
  const typeDisplay = getTypeName(currentPaper.type);
  const filename = generateFilename(currentPaper);

  // Find related marking scheme
  const relatedMS = currentPaper.type === 'qp' ? pastPapersData.find(p => 
    p.syllabus === currentPaper.syllabus &&
    p.year === currentPaper.year &&
    p.session === currentPaper.session &&
    p.component === currentPaper.component &&
    p.type === 'ms'
  ) : null;

  document.body.innerHTML = `
    <div class="viewer-container">
      <div class="viewer-header">
        <div class="container">
          <div class="viewer-title-bar">
            <div>
              <h1 class="viewer-title">${displayName} - ${component} - ${typeDisplay}</h1>
              <p style="color: var(--color-text-secondary); font-size: var(--font-size-sm); margin-top: 4px;">${filename}</p>
            </div>
            <button class="btn btn--secondary" id="backBtn">
              <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="19" y1="12" x2="5" y2="12"></line>
                <polyline points="12 19 5 12 12 5"></polyline>
              </svg>
              Back to Papers
            </button>
          </div>
          
          <div class="viewer-toolbar">
            ${relatedMS ? `
            <div class="toolbar-group">
              <button class="btn btn--primary" id="openMSBtn" data-paper='${JSON.stringify(relatedMS)}'>
                <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <line x1="16" y1="13" x2="8" y2="13"></line>
                  <line x1="16" y1="17" x2="8" y2="17"></line>
                </svg>
                Open Marking Scheme
              </button>
            </div>
            ` : ''}
            
            <div class="toolbar-group">
              <button class="btn btn--secondary" id="zoomOutBtn">
                <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="8" y1="11" x2="14" y2="11"></line>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
              </button>
              <button class="btn btn--secondary" id="zoomInBtn">
                <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="11" y1="8" x2="11" y2="14"></line>
                  <line x1="8" y1="11" x2="14" y2="11"></line>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
              </button>
              <button class="btn btn--secondary" id="resetZoomBtn">100%</button>
            </div>

            <div class="toolbar-group">
              <label style="font-size: var(--font-size-sm); color: var(--color-text-secondary);">Drawing:</label>
              <div class="color-picker">
                <div class="color-option active" data-color="#7c3aed" style="background: #7c3aed;"></div>
                <div class="color-option" data-color="#000000" style="background: #000000;"></div>
                <div class="color-option" data-color="#ef4444" style="background: #ef4444;"></div>
                <div class="color-option" data-color="#3b82f6" style="background: #3b82f6;"></div>
                <div class="color-option" data-color="#22c55e" style="background: #22c55e;"></div>
              </div>
              <button class="btn btn--secondary" id="clearAnnotationsBtn">
                <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="3 6 5 6 21 6"></polyline>
                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
                Clear
              </button>
            </div>

            <div class="toolbar-group">
              <button class="btn btn--secondary" id="downloadOriginalBtn">
                <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="7 10 12 15 17 10"></polyline>
                  <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                Download PDF
              </button>
              <button class="btn btn--primary" id="downloadAnnotatedBtn">
                <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="7 10 12 15 17 10"></polyline>
                  <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                Download with Annotations
              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="viewer-content">
        <div class="canvas-container" id="canvasContainer">
          <div style="text-align: center; padding: 64px 24px;">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin: 0 auto 16px; color: var(--color-text-secondary); opacity: 0.5;">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
            </svg>
            <h3 style="font-size: var(--font-size-xl); margin-bottom: 8px; color: var(--color-text);">PDF Viewer</h3>
            <p style="color: var(--color-text-secondary); margin-bottom: 24px;">Your PDF will be displayed here</p>
            <p style="color: var(--color-text-secondary); font-size: var(--font-size-sm);">File: /past-papers/${filename}</p>
            <p style="color: var(--color-text-secondary); font-size: var(--font-size-sm); margin-top: 16px;">Note: Upload your PDFs to the /public/past-papers/ directory to view them here</p>
          </div>
        </div>
      </div>
    </div>
  `;

  attachViewerListeners();
}

function attachViewerListeners() {
  const backBtn = document.getElementById('backBtn');
  const zoomInBtn = document.getElementById('zoomInBtn');
  const zoomOutBtn = document.getElementById('zoomOutBtn');
  const resetZoomBtn = document.getElementById('resetZoomBtn');
  const clearAnnotationsBtn = document.getElementById('clearAnnotationsBtn');
  const downloadOriginalBtn = document.getElementById('downloadOriginalBtn');
  const downloadAnnotatedBtn = document.getElementById('downloadAnnotatedBtn');
  const openMSBtn = document.getElementById('openMSBtn');

  if (backBtn) {
    backBtn.addEventListener('click', () => navigateTo('past-papers'));
  }

  if (zoomInBtn) {
    zoomInBtn.addEventListener('click', () => {
      pdfScale = Math.min(pdfScale + 0.1, 3.0);
      updateZoom();
    });
  }

  if (zoomOutBtn) {
    zoomOutBtn.addEventListener('click', () => {
      pdfScale = Math.max(pdfScale - 0.1, 0.5);
      updateZoom();
    });
  }

  if (resetZoomBtn) {
    resetZoomBtn.addEventListener('click', () => {
      pdfScale = 1.0;
      updateZoom();
    });
  }

  if (clearAnnotationsBtn) {
    clearAnnotationsBtn.addEventListener('click', clearAnnotations);
  }

  if (downloadOriginalBtn) {
    downloadOriginalBtn.addEventListener('click', () => {
      const filename = generateFilename(currentPaper);
      downloadPaper(filename);
    });
  }

  if (downloadAnnotatedBtn) {
    downloadAnnotatedBtn.addEventListener('click', downloadAnnotated);
  }

  if (openMSBtn) {
    openMSBtn.addEventListener('click', (e) => {
      const paper = JSON.parse(e.currentTarget.getAttribute('data-paper'));
      const url = `/past-papers/${generateFilename(paper)}`;
      window.open(url, '_blank');
    });
  }

  // Color picker
  document.querySelectorAll('.color-option').forEach(option => {
    option.addEventListener('click', (e) => {
      document.querySelectorAll('.color-option').forEach(o => o.classList.remove('active'));
      e.currentTarget.classList.add('active');
      drawingColor = e.currentTarget.getAttribute('data-color');
    });
  });
}

function updateZoom() {
  const resetZoomBtn = document.getElementById('resetZoomBtn');
  if (resetZoomBtn) {
    resetZoomBtn.textContent = `${Math.round(pdfScale * 100)}%`;
  }
}

function clearAnnotations() {
  annotations = [];
  // In a real implementation, this would clear the canvas
  alert('Annotations cleared!');
}

function downloadAnnotated() {
  alert('Downloading annotated PDF... (In production, this would merge annotations with the PDF)');
}

// Initialize
if (currentPage === 'home') {
  attachHomeListeners();
}